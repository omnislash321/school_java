import graph.*;

import java.io.IOException;

public class GreedyGraph extends Graph{
	private GreedyPriorityQueue gpq;
	
	public GreedyGraph(String name) throws IOException{
		gpq = new GreedyPriorityQueue();
		process_header(name);
		add_vertices();
		add_edges();
	}
	
	protected void add_vertices(){
		vertices = new GreedyVertex[order];
		for(int loop = 0; loop < order; loop ++)
			vertices[loop] = new GreedyVertex(loop);
	}

	public double costOf(int v){
		return getVertex(v).getCost();
	}

	public GreedyVertex getVertex(int v){
		return (GreedyVertex)vertices[v];
	}
	
	public void greedy(int u){
		GreedyVertex uVertex = getVertex(u);
		uVertex.setCost(0);
		gpq.add(uVertex);
		while(gpq.size() > 0){
			int v = gpq.poll().getIndex();
			markVertex(v);
			for(int w : getNeighbors(v)){
				if(getVertex(w).isFringe()){
					if(costOf(w) > newCost(v,w))
						modifyFringe(v,w);
				}else
					addFringe(v,w);
			}
		}
	}

	public boolean isSelected(Edge e){
		return getEdge(e).isSelected();
	}
	
	public double newCost(int v, int w){
		return costOf(v) + weightOf(getEdge(v,w));
	}
	
	public double weightOf(Edge e){
		return getEdge(e).getWeight();
	}
	
	public void addFringe(int v, int w){
		getEdge(v,w).setSelected(true);
		
		GreedyVertex fringe = getVertex(w);
		
		fringe.setFringe(true);
		fringe.setParent(v);
		fringe.setCost(newCost(v,w));
		
		gpq.add(fringe);
	}
	
	public void modifyFringe(int v, int w){
		getEdge(v,w).setSelected(true);
		
		GreedyVertex fringe = getVertex(w);
		
		getEdge(fringe.getParent(), w).setSelected(false);
		
		fringe.setParent(v);
		fringe.setCost(newCost(v,w));
		
		gpq.promote(fringe);
	}

}
