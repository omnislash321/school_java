import graph.*;

public class GreedyVertex extends Vertex implements Comparable<GreedyVertex>{
	protected double cost;
	protected boolean fringe;
	
	public GreedyVertex(int index){
		this(index, Double.POSITIVE_INFINITY);
	}
	
	public GreedyVertex(int index, double cost){
		super(index);
		fringe = false;
		this.cost = cost;
	}

	public int compareTo(GreedyVertex that){
		if (this.cost < that.cost) 
			return -1;
		else if (this.cost == that.cost) {
			if (this.index < that.index) 
				return -1;
			else if (this.index > that.index)
				return 1;
			
			return 0;
		}
		else 
			return 1;
	}
	
	public double getCost(){
		return cost;
	}
	
	public boolean isFringe(){
		return fringe;
	}
	
	public void setCost(double cost){
		this.cost = cost;
	}
	
	public void setFringe(boolean fringe){
		this.fringe = fringe;
	}
}
